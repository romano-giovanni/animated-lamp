package it.apuliadigital.exceptions;

public class PrestitoNotExistsException extends Exception {

    public PrestitoNotExistsException(String message) {
        super(message);
    }
}
