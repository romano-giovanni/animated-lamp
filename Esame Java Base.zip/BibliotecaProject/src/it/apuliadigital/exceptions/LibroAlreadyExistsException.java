package it.apuliadigital.exceptions;

public class LibroAlreadyExistsException extends Exception {

}
