package it.apuliadigital.exceptions;

public class PersonaNotExistsException extends Exception {

    public PersonaNotExistsException(String message) {
        super(message);
    }
}
