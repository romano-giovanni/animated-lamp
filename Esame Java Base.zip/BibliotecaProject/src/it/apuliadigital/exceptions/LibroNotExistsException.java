package it.apuliadigital.exceptions;

public class LibroNotExistsException extends Exception {

    public LibroNotExistsException(String message) {
        super(message);
    }

}
