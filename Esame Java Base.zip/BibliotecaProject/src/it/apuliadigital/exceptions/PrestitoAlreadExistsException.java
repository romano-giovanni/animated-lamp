package it.apuliadigital.exceptions;

public class PrestitoAlreadExistsException extends Exception {

    public PrestitoAlreadExistsException(String message) {
        super(message);
    }
}
