package it.apuliadigital.exceptions;

public class PersonaAlreadyExistsException extends Exception {

    public PersonaAlreadyExistsException(String message) {
        super(message);
    }
}
