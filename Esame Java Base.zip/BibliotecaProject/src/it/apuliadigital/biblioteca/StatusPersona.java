package it.apuliadigital.biblioteca;

public enum StatusPersona {
    STUDENTE,
    DOCENTE
}
