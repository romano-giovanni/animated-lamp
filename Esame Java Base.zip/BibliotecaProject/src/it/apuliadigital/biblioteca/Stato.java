package it.apuliadigital.biblioteca;

public enum Stato {
    DISPONIBILE,
    IN_PRESTITO,
    PRENOTATO
}
